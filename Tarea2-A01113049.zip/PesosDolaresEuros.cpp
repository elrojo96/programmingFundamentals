/****************************************************************************************

 Archivo: PesosDolaresEuros.cpp
 Fecha: 23 de enero de 2015.
 Author: Luis Alfonso Rojo Sanchez (A01113049)

 Descripcion:
    Este programa convierte una cantidad de pesos a dolares y euros.
 An�lisis:
    * Entradas:
        Cantidad de pesos.
    * Procesos:
        Division entre lo que vale un dolar y un peso.
    * Salidas:
        Desplegar los dolares y los euros.
 Dise�o:
    * Algoritmo:
        Preguntar la cantidad de pesos
        Leer el valor de entrada
        Conversion a dolares y euros
        Desplegar la cantidad de dolares y euros obtenida

***************************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    //Declaracion de variables
    double dValorPesos, dValorDolares, dValorEuros;

    //Se pide la cantidad de pesos
    cout << "Cual es la cantidad de pesos que quieres convertir a dolares y euros: ";
    cin >> dValorPesos;

    //Conversion a dolares y euros
    dValorDolares = dValorPesos / 14.50;
    dValorEuros = dValorPesos / 18.50;

    //Se despliegan los resultados
    cout << "La cantidad de dolares es: " << dValorDolares << endl;
    cout << "La cantidad de euros es: " << dValorEuros << endl;
    return 0;
}
