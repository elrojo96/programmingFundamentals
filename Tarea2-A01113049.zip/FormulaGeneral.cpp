/****************************************************************************************

 Archivo: FormulaGeneral.cpp
 Fecha: 23 de enero de 2015.
 Author: Luis Alfonso Rojo Sanchez (A01113049)

 Descripcion:
    Este programa calcula las 2 raices de una ecuaci�n cuadr�tica utilizando la f�rmula General.
 An�lisis:
    * Entradas:
        Valores de a,b y c.
    * Procesos:
        Utilizar la f�rmula general
    * Salidas:
        Desplegar las dos ra�ces reales
 Dise�o:
    * Algoritmo:
        Preguntar al usuario "valores de a, b y c?" ax*x + bx + c
        Leer los valores de entrada
        Usar la forma general:
        Desplegar las ra�ces reales

***************************************************************************************/

#include <iostream>
#include <math.h>

using namespace std;

int main()
{
    //Se declaran las variables
    double dValorA, dValorB, dValorC, dParte1, dParte2, dParte3, dResultadoPositivo, dResultadoNegativo;

    //Se piden los valores
    cout << "Cual es el valor de A: ";
    cin >> dValorA;
    cout << "Cual es el valor de B: ";
    cin >> dValorB;
    cout << "Cual es el valor de C: ";
    cin >> dValorC;

    //Se realizan las operaciones
    dParte1 = (-(dValorB));
    dParte2 = sqrt((dValorB * dValorB)-(4*dValorA*dValorC));
    dParte3 = 2 * dValorA;

    //Se obtienen raices reales
    dResultadoPositivo = (dParte1 + dParte2) / dParte3;
    dResultadoNegativo = (dParte1 - dParte2) / dParte3;

    //Se despliegan los resultados
    cout << "El primer resultado es: " << dResultadoPositivo << endl;
    cout << "El segundo resultado es: " << dResultadoNegativo << endl;

    return 0;
}
